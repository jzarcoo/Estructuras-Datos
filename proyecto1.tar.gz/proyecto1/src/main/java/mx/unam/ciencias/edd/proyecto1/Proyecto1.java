package mx.unam.ciencias.edd.proyecto1;

/**
 * Proyecto 1. 
 */
public class Proyecto1 extends Application {
    
    public static void main(String[] args) {
    	/* Inicia la aplicación. */
	launch(args);
    }
    
}
